"""
Модуль для работы с API MPSTAT и альтернативными источниками данных.
Содержит функции для обхода ограничений API MPSTAT и получения данных о товарах.
"""

import logging
import asyncio
import aiohttp
import json
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

async def get_external_ads_with_options(query, api_key):
    """
    Получение данных о внешней рекламе товаров через MPSTAT API
    с использованием предварительного OPTIONS-запроса.
    
    Args:
        query (str): Запрос для поиска (артикул или название товара)
        api_key (str): API ключ для доступа к MPSTAT API
        
    Returns:
        dict: Данные о внешней рекламе или информация об ошибке
    """
    try:
        # Определяем, является ли запрос артикулом (только цифры)
        is_article = query.isdigit()
        
        # Получаем данные за последние 30 дней
        today = datetime.now()
        date_to = today.strftime("%Y-%m-%d")
        date_from = (today - timedelta(days=30)).strftime("%Y-%m-%d")
        
        # Заголовки для OPTIONS-запроса
        options_headers = {
            "Content-Type": "application/json",
            "X-Mpstats-TOKEN": api_key,
            "Accept": "application/json",
            "Origin": "https://mpstats.io",
            "Access-Control-Request-Method": "GET",
            "Access-Control-Request-Headers": "X-Mpstats-TOKEN, Content-Type, Accept"
        }
        
        # Обычные заголовки для GET-запроса
        headers = {
            "Content-Type": "application/json",
            "X-Mpstats-TOKEN": api_key,
            "Accept": "application/json"
        }
        
        # URL запроса зависит от типа запроса (артикул или название товара)
        if is_article:
            # Если это артикул, используем другой URL-шаблон
            # Пробуем через основной API
            url = f"https://mpstats.io/api/wb/get/item/{query}/adverts?d1={date_from}&d2={date_to}"
        else:
            # Если это поисковый запрос, используем URL для поиска
            url = f"https://mpstats.io/api/wb/get/search?query={query}"
        
        logger.info(f"Sending OPTIONS request to MPSTAT API: {url}")
        
        # Выполняем запрос к API
        async with aiohttp.ClientSession() as session:
            # Сначала делаем OPTIONS-запрос
            async with session.options(url, headers=options_headers) as options_response:
                logger.info(f"OPTIONS response status: {options_response.status}")
                
                # Проверяем, успешен ли OPTIONS-запрос
                if options_response.status == 200:
                    logger.info(f"OPTIONS request successful")
                    
                    # Теперь делаем основной GET-запрос
                    async with session.get(url, headers=headers) as response:
                        if response.status == 200:
                            data = await response.json()
                            logger.info(f"Successfully got external ads data for query: {query}")
                            return {
                                "query": query,
                                "is_article": is_article,
                                "mpstat_data": data
                            }
                        else:
                            error_text = await response.text()
                            logger.error(f"MPSTAT API error: {error_text}")
                            # Возвращаем ошибку и переходим к альтернативному методу
                            return {"error": f"Ошибка API MPSTAT: {response.status} - {error_text}"}
                else:
                    # Если OPTIONS не прошел, пробуем альтернативный подход
                    logger.error(f"MPSTAT OPTIONS request error: {options_response.status}")
                    
                    # Пробуем использовать POST-запрос
                    logger.info(f"Trying POST request to MPSTAT API")
                    
                    # URL для POST-запроса
                    post_url = "https://mpstats.io/api/wb/get/ad"
                    post_data = {"query": query} if not is_article else {"id": query}
                    
                    async with session.post(post_url, json=post_data, headers=headers) as post_response:
                        if post_response.status == 200:
                            data = await post_response.json()
                            logger.info(f"POST request successful")
                            return {
                                "query": query,
                                "is_article": is_article,
                                "mpstat_data": data
                            }
                        else:
                            post_error = await post_response.text()
                            logger.error(f"MPSTAT POST request error: {post_response.status} - {post_error}")
                            return {
                                "error": f"Ошибка API MPSTAT: не удалось выполнить запрос (коды: {options_response.status}/{post_response.status})"
                            }
    except Exception as e:
        logger.error(f"Exception getting external ads data: {str(e)}")
        return {"error": f"Ошибка при получении данных о внешней рекламе: {str(e)}"}

async def get_serper_data(query, is_article=None):
    """
    Получение данных о товаре через Serper API (поиск Google).
    
    Args:
        query (str): Запрос для поиска (артикул или название товара)
        is_article (bool, optional): Признак того, что запрос является артикулом. 
                                     Если None, определяется автоматически.
        
    Returns:
        dict: Результаты поиска из Serper API
    """
    try:
        # Определяем, является ли запрос артикулом, если не задано явно
        if is_article is None:
            is_article = query.isdigit()
        
        # Используем Serper API для получения данных
        serper_api_key = "9c21a6aec36a7d9a6acc0ac236ce01be4a20bd38"
        serper_url = "https://google.serper.dev/search"
        
        # Формируем поисковый запрос
        search_query = query if not is_article else f"Wildberries товар артикул {query}"
        
        headers = {
            "X-API-KEY": serper_api_key,
            "Content-Type": "application/json"
        }
        
        payload = {
            "q": search_query,
            "gl": "ru",
            "hl": "ru",
            "num": 10
        }
        
        logger.info(f"Sending request to Serper API for query: {search_query}")
        
        async with aiohttp.ClientSession() as session:
            async with session.post(serper_url, json=payload, headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    logger.info(f"Successfully got Serper data for query: {search_query}")
                    return data
                else:
                    error_text = await response.text()
                    logger.error(f"Serper API error: {error_text}")
                    return {"error": f"Ошибка Serper API: {response.status} - {error_text}"}
    except Exception as e:
        logger.error(f"Exception getting Serper data: {str(e)}")
        return {"error": f"Ошибка при получении данных из Serper: {str(e)}"}

async def get_external_data_combined(query, api_key):
    """
    Комбинированная функция для получения данных о товаре из разных источников.
    Сначала пытается получить данные из MPSTAT API, а в случае ошибки использует Serper API.
    
    Args:
        query (str): Запрос для поиска (артикул или название товара)
        api_key (str): API ключ для доступа к MPSTAT API
        
    Returns:
        dict: Данные о товаре из разных источников
    """
    try:
        is_article = query.isdigit()
        
        # Сначала пробуем получить данные из MPSTAT API
        mpstat_result = await get_external_ads_with_options(query, api_key)
        
        # Также получаем данные из Serper API (параллельно)
        serper_task = asyncio.create_task(get_serper_data(query, is_article))
        
        # Ждем завершения задачи Serper
        serper_result = await serper_task
        
        # Формируем комбинированный результат
        result = {
            "query": query,
            "is_article": is_article,
        }
        
        # Добавляем данные из MPSTAT, если они есть
        if "error" not in mpstat_result:
            result["mpstat_data"] = mpstat_result.get("mpstat_data", {})
        else:
            result["mpstat_error"] = mpstat_result.get("error", "Неизвестная ошибка MPSTAT API")
        
        # Добавляем данные из Serper
        if "error" not in serper_result:
            result["serper_data"] = serper_result
            
            # Выделяем результаты Wildberries из Serper
            organic_results = serper_result.get("organic", [])
            wb_results = []
            for org_result in organic_results:
                if "wildberries" in org_result.get("link", "").lower():
                    wb_results.append(org_result)
            
            result["wb_results"] = wb_results
        else:
            result["serper_error"] = serper_result.get("error", "Неизвестная ошибка Serper API")
        
        return result
    
    except Exception as e:
        logger.error(f"Exception in combined data retrieval: {str(e)}")
        return {"error": f"Ошибка при получении комбинированных данных: {str(e)}"}

# Пример использования:
# result = await get_external_data_combined("307819738", "YOUR_API_KEY") 