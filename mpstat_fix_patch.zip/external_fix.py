"""
Улучшенная версия функции handle_external_input для обработки ошибки 405 от MPSTAT API.
Скопируйте этот код в файл new_bot.py, заменив оригинальную функцию.

ИНСТРУКЦИЯ ПО ПРИМЕНЕНИЮ:
1. Добавьте импорт в начало файла:
   from mpstat_fix import get_external_data_combined
2. Замените функцию handle_external_input на приведенную ниже
"""

@dp.message(lambda message: message.text and message.text.strip(), UserStates.waiting_for_external)
async def handle_external_input(message: types.Message, state: FSMContext):
    query = message.text.strip()
    user_id = message.from_user.id
    
    logger.info(f"User {user_id} requested external analysis for: {query}")
    
    # Проверяем баланс пользователя
    balance = subscription_manager.get_user_balance(user_id)
    if balance < COSTS["external_analysis"]:
        balance = subscription_manager.get_user_balance(user_id)
        
        if balance < COSTS["external_analysis"]:
            await message.reply(
                f"❌ *Недостаточно средств для анализа внешней рекламы*\n\n"
                f"Стоимость операции: {COSTS['external_analysis']}₽\n"
                f"Ваш баланс: {balance}₽\n\n"
                f"Пожалуйста, пополните баланс.",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Списываем средства
        subscription_manager.update_user_balance(user_id, -COSTS["external_analysis"])
        logger.info(f"Charged {COSTS['external_analysis']} for external analysis from user {user_id}")
    
    # Обновляем счетчики в подписке
    try:
        subscription_manager.increment_action_counter(user_id, "external_analysis")
    except Exception as e:
        logger.warning(f"Could not increment action counter for user {user_id}: {str(e)}")
    
    # Отправляем сообщение о начале анализа
    await message.reply("🔄 *Начинаю анализ внешней рекламы...*", parse_mode=ParseMode.MARKDOWN)
    
    # Показываем "печатает"
    await bot.send_chat_action(chat_id=message.chat.id, action=ChatAction.TYPING)
    
    try:
        # Используем улучшенную функцию для получения данных о внешней рекламе
        try:
            # Импортируем функцию из модуля mpstat_fix
            from mpstat_fix import get_external_data_combined
            
            # Используем улучшенную функцию
            external_data = await get_external_data_combined(query, MPSTA_API_KEY)
            logger.info(f"Got combined external data for query: {query}")
        except ImportError:
            # Если модуль не импортирован, используем стандартный метод
            logger.warning("Could not import mpstat_fix module, using default method")
            external_data = await get_external_ads_data(query)
        
        # Если произошла ошибка, но есть данные из Serper, продолжаем с ними
        if "mpstat_error" in external_data and "serper_data" in external_data:
            logger.warning(f"MPSTAT API error, continuing with Serper data: {external_data.get('mpstat_error')}")
            await message.reply(
                f"⚠️ *Предупреждение*\n\n"
                f"Не удалось получить полные данные от MPSTAT API: {external_data.get('mpstat_error')}\n"
                f"Продолжаем анализ с использованием доступных данных из альтернативных источников.",
                parse_mode=ParseMode.MARKDOWN
            )
        
        # Если есть полная ошибка, которая не позволяет продолжать, сообщаем пользователю
        if "error" in external_data:
            await message.reply(
                f"❌ *Ошибка при получении данных*\n\n{external_data['error']}",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        
        # Подготавливаем данные для форматирования
        formatted_data = {
            "query": external_data.get("query", query),
            "is_article": external_data.get("is_article", query.isdigit()),
            "product_info": external_data.get("product_info", {}),
            "ad_items": [],
            "bloggers_data": {}
        }
        
        # Добавляем данные из MPSTAT, если они есть
        if "mpstat_data" in external_data:
            mpstat_data = external_data["mpstat_data"]
            
            # Обрабатываем данные в зависимости от структуры ответа
            if "items" in mpstat_data:
                formatted_data["ad_items"] = mpstat_data["items"]
            
            # Добавляем информацию о товаре, если есть
            if "name" in mpstat_data:
                formatted_data["product_info"] = mpstat_data
        
        # Добавляем данные из Serper, если их нет из MPSTAT
        if not formatted_data["ad_items"] and "wb_results" in external_data:
            # Добавляем базовую информацию из результатов Wildberries в Serper
            for result in external_data.get("wb_results", []):
                # Создаем запись о рекламе на основе данных Serper
                ad_item = {
                    "platform": "Serper",
                    "blogger": {"name": "Unknown"},
                    "date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
                    "url": result.get("link", ""),
                    "title": result.get("title", ""),
                    "snippet": result.get("snippet", "")
                }
                formatted_data["ad_items"].append(ad_item)
        
        # Форматируем данные для отображения
        formatted_result, chart_files = format_external_analysis(formatted_data)
        
        # Если есть графики, отправляем их
        if chart_files:
            media = []
            
            for chart_file in chart_files:
                try:
                    photo = FSInputFile(chart_file)
                    media.append(InputMediaPhoto(media=photo))
                except Exception as e:
                    logger.error(f"Error adding chart to media group: {str(e)}")
            
            if media:
                try:
                    await bot.send_media_group(chat_id=message.chat.id, media=media)
                except Exception as e:
                    logger.error(f"Error sending media group: {str(e)}")
                    
                    # Если не удалось отправить медиагруппу, пробуем отправить графики по одному
                    for chart_file in chart_files:
                        try:
                            await bot.send_photo(
                                chat_id=message.chat.id,
                                photo=FSInputFile(chart_file),
                                caption="График анализа внешней рекламы"
                            )
                        except Exception as chart_e:
                            logger.error(f"Error sending chart: {str(chart_e)}")
            
            # Удаляем временные файлы
            for chart_file in chart_files:
                try:
                    os.remove(chart_file)
                except Exception as e:
                    logger.error(f"Error removing temp file {chart_file}: {str(e)}")
        
        # Отправляем отчет
        await message.reply(
            formatted_result,
            parse_mode=ParseMode.MARKDOWN
        )
        
        # Предлагаем меню
        await message.answer(
            "📊 *Анализ завершен*\n\nЧто хотите сделать дальше?",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=main_menu_kb()
        )
        
        # Очищаем состояние
        await state.clear()
    
    except Exception as e:
        logger.error(f"Error in external analysis: {str(e)}", exc_info=True)
        
        await message.reply(
            "❌ *Произошла ошибка при выполнении анализа*\n\n"
            f"Детали: {str(e)}\n\n"
            "Пожалуйста, попробуйте позже или выберите другой товар/артикул.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=back_keyboard()
        ) 